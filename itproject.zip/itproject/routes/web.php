<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('pages.schedule');
});

Route::get('/patient', function () {
    return view('pages.patient');
});

Route::get('/patientrecords', function () {
    return view('pages.patientrecords');
});

Route::get('/patienttransactions', function () {
    return view('pages.patienttransactions');
});

Route::get('/patientmedicalrecords', function () {
    return view('pages.patientmedicalrecords');
});

Route::get('/patientbalance', function () {
    return view('pages.patientbalance');
});

Route::get('/viewschedhistory', function () {
    return view('pages.viewschedhistory');
});

Route::get('/patientteethchart', function () {
    return view('pages.patientteethchart');
});

Route::get('/sales', function () {
    return view('pages.sales');
});